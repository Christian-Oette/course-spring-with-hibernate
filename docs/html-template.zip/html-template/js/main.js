;(function () {

	'use strict';

	// Loading page
	var loaderPage = function() {
		$(".gtco-loader").fadeOut("slow");
	};


	$(function(){
		loaderPage();
	});


}());